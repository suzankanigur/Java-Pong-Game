import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class Board {

	private int x, y; // positions
	private int vel = 0; // speed and direction of board
	private int speed = 10; // speed of the board movement
	private int width = 22, height = 85; // dimensions
	private int score = 0; // score for the player
	private Color color; // color of the paddle
	private boolean left; // true if it's the left board
	
	public Board(Color c, boolean left) {
		// creating the initial properties for the boards
		color = c;
		this.left = left;

		if (left) { //Is it the left paddle?
			x = 0;
		}
		else {
			x = Game.WIDTH - width;
		}
		y = Game.HEIGHT / 2 - height / 2;
	}

	public void addPoint() {
		score++;
	}
	
	public void update(Ball ball) { 

		// update position
		y = Game.ensureRange(y + vel, 0, Game.HEIGHT - height);

		// collisions
		int ballX = ball.getX();
		int ballY = ball.getY();

		if (left) {
			if (ballX <= width + x && ballY + Ball.SIZE >= y && ballY <= y + height) {
				ball.changeXDirection();
			}

		} else {
			if (ballX + Ball.SIZE >= x && ballY + Ball.SIZE >= y && ballY <= y + height) {
				ball.changeXDirection();
			}
		}
	}

	//Graphics object is used to draw all of it
	public void draw(Graphics g) { //drawing the board and score board

		// drawing the board
		g.setColor(color);
		g.fillRect(x, y, width, height);

		// drawing the score
		int sx; 
		int padding = 25; // space
		String scoreText = Integer.toString(score);
		Font font = new Font("Roboto", Font.PLAIN, 50);

		if (left) {
			int strWidth = g.getFontMetrics(font).stringWidth(scoreText); // we need the width of the string so we can
																			// center it properly (for perfectionists)
			sx = Game.WIDTH / 2 - padding - strWidth;
		} 
		
		else {
			sx = Game.WIDTH / 2 + padding;
		}

		g.setFont(font);
		g.drawString(scoreText, sx, 50);
	}

	public void stop() { //board stop
		vel = 0;
	}
	
	public void switchDirections(int direction) { //-1 up, 1 down
		vel = speed * direction; 
	}
}
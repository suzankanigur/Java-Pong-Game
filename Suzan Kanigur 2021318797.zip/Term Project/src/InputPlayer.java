import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class InputPlayer extends KeyAdapter {

	private Board leftBoard; 
	private boolean leftUp = false; 
	private boolean leftDown = false;

	private Board rightBoard; 
	private boolean rightUp = false;
	private boolean rightDown = false;

	public InputPlayer(Board p1, Board p2) {
		leftBoard = p1;
		rightBoard = p2;
	}

	@Override
	public void keyPressed(KeyEvent e) {
		int key = e.getKeyCode();

		if (key == KeyEvent.VK_UP) {
			rightBoard.switchDirections(-1);
			rightUp = true;
		}
		if (key == KeyEvent.VK_W) {
			leftBoard.switchDirections(-1);
			leftUp = true;
		}
		if (key == KeyEvent.VK_S) {
			leftBoard.switchDirections(1);
			leftDown = true;
		}
		if (key == KeyEvent.VK_ESCAPE) {
			System.exit(1);
		}
		if (key == KeyEvent.VK_DOWN) {
			rightBoard.switchDirections(1);
			rightDown = true;
		}

	}

	@Override
	public void keyReleased(KeyEvent e) {
		int key = e.getKeyCode();

		if (!leftUp && !leftDown) {
			leftBoard.stop();
		}
		if (!rightUp && !rightDown) {
			rightBoard.stop();
		}
		if (key == KeyEvent.VK_W) {
			leftUp = false;
		}
		if (key == KeyEvent.VK_DOWN) {
			rightDown = false;
		}
		if (key == KeyEvent.VK_UP) {
			rightUp = false;
		}
		if (key == KeyEvent.VK_S) {
			leftDown = false;
		}
	}
}
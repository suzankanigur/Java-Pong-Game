import javax.swing.JFrame;
public class Window {
	public Window(String title, Game game) { //frame creation
		JFrame frame = new JFrame(title);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.add(game); // Game inherits from Canvas, a Component object, so it can be put in a JFrame
		frame.pack();
		frame.setLocationRelativeTo(null); //window centering
		frame.setVisible(true);
	}
	//I had little idea about this part, so I took a bit of help from Youtube videos.
}
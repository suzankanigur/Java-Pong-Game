import java.awt.Color;
import java.awt.Graphics;

public class Ball {
	public static final int SIZE = 16;
	private int x, y; //position of top left corner of square
	private int xVelocity, yVelocity; //either 1 or -1
	private int speed = 5; //speed of the ball

	public Ball() { //constructor
		reset();
	}

	public void draw(Graphics g) {
		g.setColor(Color.white);
		g.fillRect(x, y, SIZE, SIZE);
	}
	
	private void reset() { 
		//setting up the initial position
		
		x = Game.WIDTH / 2 - SIZE / 2;
		y = Game.HEIGHT / 2 - SIZE / 2;

		//setting up the initial velocity
		
		xVelocity = Game.sign(Math.random() * 2.0 - 1);
		yVelocity = Game.sign(Math.random() * 2.0 - 1);
	}

	public void update(Board leftBoard, Board rightBoard) {

		//position update
		x += xVelocity * speed;
		y += yVelocity * speed;
		
		//collisions; with walls
		if (x + SIZE >= Game.WIDTH) { //right wall
			leftBoard.addPoint();
			reset();
		}
		if (x <= 0) { // left wall
			rightBoard.addPoint();
			reset();
		}
		//collisions; with ceiling and floor
		if (y + SIZE >= Game.HEIGHT || y <= 0) {
			changeYDirection();
		}
	}
	
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
	public void changeXDirection() { //if the ball is going right, go left; if ball is going left, go right.
		xVelocity *= -1;
	}
	public void changeYDirection() { //if the ball is going up, go down; if ball is going down, go up.
		yVelocity *= -1;
	}
}
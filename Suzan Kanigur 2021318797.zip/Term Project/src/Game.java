import java.awt.BasicStroke;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.image.BufferStrategy;

public class Game extends Canvas implements Runnable { //this is the class that manages the game, drawing and updating physics

	private static final long serialVersionUID = 1L;
	public final static int WIDTH = 1000;
	public final static int HEIGHT = WIDTH * 9 / 16; // 16:9 aspect ratio
	public boolean running = false; // true if the game is running
	private Thread gameThread; // thread where the game is updated AND drawn (single thread game)

	private Ball ball;
	private Board leftBoard;
	private Board rightBoard;
	private FirstMenu menu; // Main Menu object

	public Game() { //constructor

		canvasSetup();
		new Window("Simple Pong", this);
		initialise();
		this.addKeyListener(new InputPlayer(leftBoard, rightBoard));
		this.addMouseListener(menu);
		this.addMouseMotionListener(menu);
		this.setFocusable(true);

	}

	private void canvasSetup() { //setting up the canvas to our desired settings and sizes
		this.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		this.setMaximumSize(new Dimension(WIDTH, HEIGHT));
		this.setMinimumSize(new Dimension(WIDTH, HEIGHT));
	}

	private void initialise() { //Initialize all our game objects
		
		ball = new Ball(); //Initialize Ball object

		// Initialize Board objects
		leftBoard = new Board(Color.green, true);
		rightBoard = new Board(Color.red, false);

		// initialize main menu
		menu = new FirstMenu(this);
	}

	@Override
	public void run() { //Game loop
		//I could not manage the game loop so I got help on this part only

		this.requestFocus();
		long lastTime = System.nanoTime(); //Timer
		double amountOfTicks = 60.0;
		double ns = 1000000000 / amountOfTicks;
		double delta = 0;
		long timer = System.currentTimeMillis();
		int frames = 0;
		while (running) {
			long now = System.nanoTime();
			delta += (now - lastTime) / ns;
			lastTime = now;
			if (System.currentTimeMillis() - timer > 1000) {
				timer += 1000;
				System.out.println("FPS: " + frames);
				frames = 0;
			}
			if (delta >= 1) {
				update();
				delta--;
				draw();
				frames++;
			}
		}
		stop();
	}

	public synchronized void start() { //Start the thread and the game
		gameThread = new Thread(this);
		gameThread.start(); 
		running = true;
	}
	public void stop() {
		try {
			gameThread.join();
			running = false;
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	private void drawBackground(Graphics g) { //I took some help from the internet for this part since I do not have enough knowledge
		g.setColor(Color.black);
		g.fillRect(0, 0, WIDTH, HEIGHT);
		g.setColor(Color.white);
		Graphics2D g2d = (Graphics2D) g; // more complex Graphics class for drawing the objects 
		// How to make a dotted line:
		Stroke dashed = new BasicStroke(3, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[] { 10 }, 0);
		g2d.setStroke(dashed);
		g.drawLine(WIDTH / 2, 0, WIDTH / 2, HEIGHT);
	}

	public void draw() { 

		BufferStrategy buffer = this.getBufferStrategy(); // extract buffer so we can use them

		if (buffer == null) { // unless it exist, we cannot draw so we need to create it first
			this.createBufferStrategy(3); // Creating a Triple Buffer
			 //BufferStrategy: https://docs.oracle.com/javase/7/docs/api/java/awt/image/BufferStrategy.html
			return;
		}

		Graphics g = buffer.getDrawGraphics(); // extracting the drawings tool from the buffers
		//Graphics class is the tool for drawing on a buffer. 
		//https://docs.oracle.com/javase/7/docs/api/java/awt/Graphics.html

		drawBackground(g);

		if (menu.active) {
			menu.draw(g);
		}
		ball.draw(g);
		leftBoard.draw(g);
		rightBoard.draw(g);
		g.dispose(); 
		buffer.show(); 
	}
	
	public void update() { //the settings

		if (!menu.active) {
			ball.update(leftBoard, rightBoard);
			leftBoard.update(ball);
			rightBoard.update(ball);
		}
	}
	
	public static int sign(double d) {
		if (d <= 0)
			return -1;
		return 1;
	}
	
	public static int ensureRange(int value, int min, int max) {
		return Math.min(Math.max(value, min), max); 
		//If the value is between min and max, return the value. 
		//If the value is smaller than min, return min.
		//If the value is bigger than max, return max. 
	}
	
	public static void main(String[] args) { //The programme starts here
		new Game();
	}
}
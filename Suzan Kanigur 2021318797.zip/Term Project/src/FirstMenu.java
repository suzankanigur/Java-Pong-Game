import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class FirstMenu extends MouseAdapter {

	public boolean active; //true when menu is showing

	// Features for the play button 
	private Rectangle playButton; 
	private String playText = "Play";
	private boolean playHighlight = false;
	
	// Features for the quit button
	private Rectangle quitButton; // Quit Button
	private String quitText = "Quit";
	private boolean quitHighlight = false; //when the mouse is on the buttons, without clicking, it will have a highlight 

	private Font font;

	public FirstMenu(Game game) {

		active = true;
		game.start();

		// dimensions & positions of each button
		int x, y, w, h;

		w = 300;
		h = 150;
		y = Game.HEIGHT/2 - h/2;
		x = Game.WIDTH/4 - w/2;
		playButton = new Rectangle(x, y, w, h);

		x = Game.WIDTH*3/4 - w/2;
		quitButton = new Rectangle(x, y, w, h);
		font = new Font("Roboto", Font.PLAIN, 100);
	}

	@Override
	public void mouseClicked(MouseEvent e) {

		Point p = e.getPoint();

		if (playButton.contains(p)) {
			active = false;
		}
		else if (quitButton.contains(p)) {
			System.exit(0);
		}
	}
	
	public void draw(Graphics g) { //While drawing everything, the graphics object is being used 
		Graphics2D g2d = (Graphics2D) g;
		g.setFont(font);

		// draw buttons
		g.setColor(Color.black);
		if (playHighlight) {
			g.setColor(Color.white);
		}
		g2d.fill(playButton);

		g.setColor(Color.black);
		if (quitHighlight) {
			g.setColor(Color.white);
		}
		g2d.fill(quitButton);

		// draw button borders
		g.setColor(Color.white);
		g2d.draw(playButton);
		g2d.draw(quitButton);

		// draw text in buttons

		int strWidth, strHeight;

		// Play Button text
		strWidth = g.getFontMetrics(font).stringWidth(playText);
		strHeight = g.getFontMetrics(font).getHeight();

		g.setColor(Color.green);
		g.drawString(playText, (int) (playButton.getX() + playButton.getWidth() / 2 - strWidth / 2),
				(int) (playButton.getY() + playButton.getHeight() / 2 + strHeight / 4));

		// Quit Button text
		strWidth = g.getFontMetrics(font).stringWidth(quitText);
		strHeight = g.getFontMetrics(font).getHeight();

		g.setColor(Color.red);
		g.drawString(quitText, (int) (quitButton.getX() + quitButton.getWidth() / 2 - strWidth / 2),
				(int) (quitButton.getY() + quitButton.getHeight() / 2 + strHeight / 4));
	}

	@Override
	public void mouseMoved(MouseEvent e) {

		Point p = e.getPoint();
		// determine if mouse is hovering inside one of the buttons
		playHighlight = playButton.contains(p);
		quitHighlight = quitButton.contains(p);
	}
}